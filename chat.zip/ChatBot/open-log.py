import streamlit as st
from dotenv import load_dotenv
from transformers import BertTokenizer, BertModel
from htmlTemplates import css, bot_template, user_template
import openai
import os

# Set your OpenAI API key
openai.api_key = "sk-proj-1oX0mDzs90vFlBHrxCr3T3BlbkFJTaI8mT8rKxbQaaHR9zFN"

def split_text_into_chunks(text, chunk_size=1000):
    chunks = []
    for i in range(0, len(text), chunk_size):
        chunks.append(text[i:i+chunk_size])
    return chunks

def get_log_text(log_file_path):
    with open(log_file_path, 'r') as file:
        text = file.read()
    return text

def get_bert_embeddings(text_chunks):
    # Load BERT tokenizer and model
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertModel.from_pretrained('bert-base-uncased')

    # Process text chunks
    embeddings = []
    for chunk in text_chunks:
        inputs = tokenizer(chunk, return_tensors="pt", max_length=512, truncation=True, padding=True)
        outputs = model(**inputs)
        pooled_output = outputs.last_hidden_state.mean(dim=1)  # Mean pooling
        embeddings.append(pooled_output.tolist())
    
    return embeddings

def handle_user_input(user_question, memory):
    response = openai.Completion.create(
        engine="gpt-3.5-turbo-instruct",
        prompt=user_question,
        max_tokens=150
    )
    st.session_state.chat_history.append(response.choices[0].text.strip())
    memory.extend(st.session_state.chat_history)

    for i, message in enumerate(st.session_state.chat_history):
        if i % 2 == 0:
            st.write(user_template.replace("{{MSG}}", user_question), unsafe_allow_html=True)
        else:
            st.write(bot_template.replace("{{MSG}}", message), unsafe_allow_html=True)

def main():
    load_dotenv()
    st.set_page_config(page_title="Chat with your GPT")
    st.write(css, unsafe_allow_html=True)

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    memory = st.session_state.chat_history

    st.header("Nova Bot")

    # Option to manually input the path to a log file
    log_file_path = st.text_input("Enter the path to your log file:")

    # Option to upload a log file
    uploaded_file = st.file_uploader("Upload your log file here:", type=["txt", "log"])

    if log_file_path:
        if st.button("Process"):
            with st.spinner("Processing"):
                raw_text = get_log_text(log_file_path)
                text_chunks = split_text_into_chunks(raw_text)
                vectorstore = get_bert_embeddings(text_chunks)
    elif uploaded_file:
        if st.button("Process"):
            with st.spinner("Processing"):
                file_contents = uploaded_file.read().decode("utf-8")
                text_chunks = split_text_into_chunks(file_contents)
                vectorstore = get_bert_embeddings(text_chunks)

    user_question = st.text_input("Ask a question about your documents:")
    if user_question:
        handle_user_input(user_question, memory)

    with st.sidebar:
        st.subheader("Your documents")
        # Removed file uploader for log files since we're providing options to input via text input or upload
        # pdf_docs = st.file_uploader(
        #     "Upload your PDFs here and click on 'Process'", accept_multiple_files=True)
        # if st.button("Process"):
        #     with st.spinner("Processing"):
        #         raw_text = get_pdf_text(pdf_docs)
        #         text_chunks = split_text_into_chunks(raw_text)
        #         vectorstore = get_vectorstore(text_chunks)

if __name__ == '__main__':
    main()
